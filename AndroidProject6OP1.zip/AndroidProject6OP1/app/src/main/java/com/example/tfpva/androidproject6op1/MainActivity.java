package com.example.tfpva.androidproject6op1;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    public final static String EXTRA_MESSAGE = "com.example.tfpva.androidproject6op1.Message";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    //Wordt aangeroepen wanneer de gebruiker de send knop klikt
    public void sendMessage(View view){
        Log.w("Intent", "Maak en gebruik message activity");
        //Begint de communicate met de display message activity
        Intent intent = new Intent(this, DisplayMessageActivity.class);
        //Pas de tekst aan naar de input van de gebruiker en sla deze op in de message
        EditText editText = (EditText)findViewById(R.id.edit_message);
        String message = editText.getText().toString();
        Log.w("Bericht", "De input van de gebruiker is overgezet naar string in intent");
        //Stuur het bericht naar de activity
        intent.putExtra(EXTRA_MESSAGE,message);
        //Begint de display message activity
        startActivity(intent);
        Log.w("Bericht activiteit", "Het bericht komt nu op beeld te staan in zijn activiteit");
    }

    public void SpeelVideo(View view){
        //De video url komt van http://camendesign.com/code/video_for_everybody/test.html.
        String videourl = "http://clips.vorwaerts-gmbh.de/VfE_html5.mp4";
        Uri uri = Uri.parse(videourl);
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        intent.setDataAndType(uri, "video/mp4");
        Log.w("Video", "De video is vanaf url naar intent gekopierd, deze wordt nu gestart");
        startActivity(intent);
        Log.w("Vid gestart", "De video activiteit is nu begonnen. De gebruiker ziet deze nu");
    }

}
