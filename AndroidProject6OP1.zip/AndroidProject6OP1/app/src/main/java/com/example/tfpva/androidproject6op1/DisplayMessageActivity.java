package com.example.tfpva.androidproject6op1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class DisplayMessageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_message);

        Log.w("Get intent", "Pak de activity die deze activity begon");
        //Pakt de intent waardoor de activity is begonnen
        Intent intent = getIntent();
        //Maakt van het ontvangen bericht een String
        String message= intent.getStringExtra(MainActivity.EXTRA_MESSAGE);
        Log.w("Teksvak", "Maakt tekstvak waarin het bericht komt te staan");
        //Maakt het tekstvak waarin het bericht komt te staan, en laat het bericht zien
        TextView textView = new TextView(this);
        textView.setTextSize(28);
        textView.setText(message);

        //Neemt de layout over van ViewGroup
        ViewGroup layout = (ViewGroup) findViewById(R.id.activity_display_message);
        layout.addView(textView);
    }
}
//TODO Database waarin je oudere berichten opslaat zodat de gebruiker deze kan terug lezen